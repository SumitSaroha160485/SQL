--SQL Advance Case Study
use db_SQLCaseStudies;

--Q1--BEGIN 

Select Distinct DIM_LOCATION.State
from DIM_LOCATION
Join FACT_TRANSACTIONS on DIM_LOCATION.IDLocation = FACT_TRANSACTIONS.IDLocation
WHERE FACT_TRANSACTIONS.Date>= '2005-01-01' AND FACT_TRANSACTIONS.Date <= GETDATE();



--Q1--END

--Q2--BEGIN

SELECT DIM_LOCATION.Country, COUNT(*) as Total_Samsung_Purchases
FROM DIM_LOCATION
JOIN FACT_TRANSACTIONS ON DIM_LOCATION.IDLocation = FACT_TRANSACTIONS.IDLocation
JOIN DIM_MODEL ON FACT_TRANSACTIONS.IDModel = DIM_MODEL.IDModel
JOIN DIM_MANUFACTURER ON DIM_MODEL.IDManufacturer = DIM_MANUFACTURER.IDManufacturer
WHERE DIM_MANUFACTURER.Manufacturer_Name = 'Samsung'
GROUP BY DIM_LOCATION.Country
ORDER BY Total_Samsung_Purchases DESC;

	
--Q2--END

--Q3--BEGIN      
	
SELECT
    DIM_CUSTOMER.IDCustomer,
    DIM_LOCATION.State,
    DIM_LOCATION.ZipCode,
    DIM_MODEL.Model_Name,
    COUNT(FACT_TRANSACTIONS.TotalPrice) AS Transaction_Count
FROM
    DIM_CUSTOMER
JOIN
    FACT_TRANSACTIONS ON DIM_CUSTOMER.IDCustomer = FACT_TRANSACTIONS.IDCustomer
JOIN
    DIM_MODEL ON FACT_TRANSACTIONS.IDModel = DIM_MODEL.IDModel
JOIN
    DIM_LOCATION ON FACT_TRANSACTIONS.IDLocation = DIM_LOCATION.IDLocation
GROUP BY
    DIM_CUSTOMER.IDCustomer, DIM_LOCATION.State, DIM_LOCATION.ZipCode, DIM_MODEL.Model_Name
ORDER BY
    DIM_LOCATION.State, DIM_LOCATION.ZipCode, DIM_MODEL.Model_Name;




--Q3--END

--Q4--BEGIN
SELECT
    DIM_MODEL.Model_Name,
    FACT_TRANSACTIONS.TotalPrice AS Price
FROM
    DIM_MODEL
JOIN
    FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
ORDER BY
    FACT_TRANSACTIONS.TotalPrice;





--Q4--END

--Q5--BEGIN

WITH TopMakers AS (
    SELECT
        DIM_MANUFACTURER.IDManufacturer,
        DIM_MANUFACTURER.Manufacturer_Name,
        SUM(FACT_TRANSACTIONS.Quantity) AS TotalSales
    FROM
        DIM_MANUFACTURER
    JOIN
        DIM_MODEL ON DIM_MANUFACTURER.IDManufacturer = DIM_MODEL.IDManufacturer
    JOIN
        FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
    GROUP BY
        DIM_MANUFACTURER.IDManufacturer, DIM_MANUFACTURER.Manufacturer_Name
    ORDER BY
        TotalSales DESC
    OFFSET 0 ROWS 
    FETCH FIRST 5 ROWS ONLY
)

SELECT
    TopMakers.Manufacturer_Name,
    DIM_MODEL.Model_Name,
    AVG(FACT_TRANSACTIONS.TotalPrice) AS AveragePrice
FROM
    TopMakers
JOIN
    DIM_MODEL ON TopMakers.IDManufacturer = DIM_MODEL.IDManufacturer 
JOIN
    FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
GROUP BY
    TopMakers.Manufacturer_Name, DIM_MODEL.Model_Name
ORDER BY
    AveragePrice;













--Q5--END

--Q6--BEGIN



SELECT DIM_CUSTOMER.Customer_Name,
AVG(FACT_TRANSACTIONS.TotalPrice) AS AverageAmountSpent
FROM DIM_CUSTOMER
JOIN FACT_TRANSACTIONS ON DIM_CUSTOMER.IDCustomer = FACT_TRANSACTIONS.IDCustomer
Where YEAR(FACT_TRANSACTIONS.Date) = 2009
GROUP BY DIM_CUSTOMER.Customer_Name
HAVING AVG(FACT_TRANSACTIONS.TotalPrice) > 500;









--Q6--END
	
--Q7--BEGIN  
	
WITH TopModel AS (
    SELECT
        DIM_MODEL.IDModel,
        DIM_MODEL.Model_Name,
        YEAR(FACT_TRANSACTIONS.Date) AS Transaction_Year,
        SUM(FACT_TRANSACTIONS.Quantity) AS TotalQuantity
    FROM
        DIM_MODEL
    JOIN
        FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
    WHERE
        YEAR(FACT_TRANSACTIONS.Date) IN (2008, 2009, 2010)
    GROUP BY
         DIM_MODEL.IDModel,DIM_MODEL.Model_Name, YEAR(FACT_TRANSACTIONS.Date)
)

SELECT
   TopModel.Model_Name
FROM
    TopModel
WHERE
    TopModel.Transaction_Year IN (2008, 2009, 2010)
GROUP BY
    TopModel.Model_Name
HAVING
    COUNT(DISTINCT TopModel.Transaction_Year) = 3;
	
















--Q7--END	
--Q8--BEGIN

WITH ManufacturerRanked AS (
    SELECT
        DIM_MANUFACTURER.IDManufacturer,
        DIM_MANUFACTURER.Manufacturer_Name,
        YEAR(FACT_TRANSACTIONS.Date) AS Transaction_Year,
        SUM(FACT_TRANSACTIONS.Quantity) AS TotalSales,
        DENSE_RANK() OVER (PARTITION BY YEAR(FACT_TRANSACTIONS.Date) ORDER BY SUM(FACT_TRANSACTIONS.Quantity) DESC) AS SalesRank
    FROM
        DIM_MANUFACTURER
    JOIN
        DIM_MODEL ON DIM_MANUFACTURER.IDManufacturer = DIM_MODEL.IDManufacturer
    JOIN
        FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
    WHERE
        YEAR(FACT_TRANSACTIONS.Date) IN (2009, 2010)
    GROUP BY
        DIM_MANUFACTURER.IDManufacturer, DIM_MANUFACTURER.Manufacturer_Name, YEAR(FACT_TRANSACTIONS.Date)
)

SELECT
    Transaction_Year,
    Manufacturer_Name
FROM
    ManufacturerRanked
WHERE
    SalesRank = 2;



















--Q8--END
--Q9--BEGIN


SELECT
    DIM_MANUFACTURER.IDManufacturer,
    DIM_MANUFACTURER.Manufacturer_Name
FROM DIM_MANUFACTURER
WHERE
    EXISTS (
        SELECT 1
        FROM DIM_MODEL
        JOIN FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
        where DIM_MODEL.IDManufacturer = DIM_MANUFACTURER.IDManufacturer
        AND YEAR(FACT_TRANSACTIONS.Date) = 2010
    )
    AND NOT EXISTS (
        SELECT 1
        FROM DIM_MODEL
        JOIN FACT_TRANSACTIONS ON DIM_MODEL.IDModel = FACT_TRANSACTIONS.IDModel
        WHERE DIM_MODEL.IDManufacturer = DIM_MANUFACTURER.IDManufacturer
        AND YEAR(FACT_TRANSACTIONS.Date) = 2009
    );	

















--Q9--END

--Q10--BEGIN


WITH Top100Customers AS (
    SELECT
        DIM_CUSTOMER.IDCustomer,
        DIM_CUSTOMER.Customer_Name,
        YEAR(FACT_TRANSACTIONS.Date) AS Transaction_Year,
        AVG(FACT_TRANSACTIONS.TotalPrice) AS AvgSpend,
        AVG(FACT_TRANSACTIONS.Quantity) AS AvgQuantity
    FROM
        DIM_CUSTOMER
    JOIN
        FACT_TRANSACTIONS ON DIM_CUSTOMER.IDCustomer = FACT_TRANSACTIONS.IDCustomer
    GROUP BY
        DIM_CUSTOMER.IDCustomer, DIM_CUSTOMER.Customer_Name, YEAR(FACT_TRANSACTIONS.Date)
)

SELECT
    tc.IDCustomer,
    tc.Customer_Name,
    tc.Transaction_Year,
    tc.AvgSpend,
    tc.AvgQuantity,
    LAG(tc.AvgSpend) OVER (PARTITION BY tc.IDCustomer ORDER BY tc.Transaction_Year) AS PrevYearAvgSpend,
    CASE
        WHEN LAG(tc.AvgSpend) OVER (PARTITION BY tc.IDCustomer ORDER BY tc.Transaction_Year) IS NULL THEN NULL
        WHEN LAG(tc.AvgSpend) OVER (PARTITION BY tc.IDCustomer ORDER BY tc.Transaction_Year) = 0 THEN NULL
        ELSE ((tc.AvgSpend - LAG(tc.AvgSpend) OVER (PARTITION BY tc.IDCustomer ORDER BY tc.Transaction_Year)) / LAG(tc.AvgSpend) OVER (PARTITION BY tc.IDCustomer ORDER BY tc.Transaction_Year)) * 100
    END AS PercentageChange
FROM
    Top100Customers tc
ORDER BY
    tc.IDCustomer, tc.Transaction_Year
OFFSET 0 ROWS FETCH NEXT 100 ROWS ONLY;






















--Q10--END
	